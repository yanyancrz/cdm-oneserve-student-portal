import { API_URL } from "../config/api";


const BASE = `${API_URL}/api/library`;

const getToken = () =>
    localStorage.getItem("token") ||
    localStorage.getItem("authToken") ||
    "";

async function request(path, options = {}) {

    const token = getToken();

    const res = await fetch(`${BASE}${path}`, {
        ...options,
        headers: {
            "Content-Type": "application/json",
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
            ...(options.headers || {})
        }
    });

    let data = null;

    try {
        data = await res.json();
    } catch {
        data = null;
    }

    if (!res.ok) {
        throw new Error(
            data?.message || `Library API error (${res.status})`
        );
    }

    return data;
}

// ---------------------------------------------------------------------------
// BOOKS
// ---------------------------------------------------------------------------

export function getBooks(params = {}) {
    const query = new URLSearchParams(params).toString();
    return request(`/books${query ? `?${query}` : ""}`);
}

export function getBook(bookId) {
    return request(`/books/${bookId}`);
}


// ---------------------------------------------------------------------------
// BORROWING / RESERVATIONS / RENEWALS
// ---------------------------------------------------------------------------

export function borrowBook(userId, bookId) {
    return request("/borrow", {
        method: "POST",
        body: JSON.stringify({
            userId: Number(userId),
            bookId: Number(bookId),
        }),
    });
}

export function reserveBook(userId, bookId) {
    return request("/reservations", {
        method: "POST",
        body: JSON.stringify({
            userId: Number(userId),
            bookId: Number(bookId),
        }),
    });
}

export function cancelReservation(reservationId) {
    return request(`/reservations/cancel/${reservationId}`, {
        method: "PUT",
    });
}

export function renewBook(borrowId) {
    return request(`/borrow/renew/${borrowId}`, {
        method: "PUT",
    });
}

export function claimReservedBook(reservationId) {
    return request(`/reservations/claim/${reservationId}`, {
        method: "POST",
    });
}

export function getMyReservations(userId) {
    return request(`/reservations/student/${userId}`);
}

export function returnBook(borrowId) {
    return request(`/borrow/return/${borrowId}`, {
        method: "PUT",
    });
}

// ---------------------------------------------------------------------------
// HISTORY / FAVORITES
// ---------------------------------------------------------------------------

export function getBorrowHistory(userId) {
    return request(`/borrow/student/${userId}`);
}

export function getFavorites(userId) {
    return request(`/favorites/${userId}`);
}

export function toggleFavorite(userId, bookId) {
    return request(`/favorites/${userId}/${bookId}`, {
        method: "POST",
    });
}

export function getCurrentBorrowedBooks(userId) {
    return request(`/borrow/current/${userId}`);
}

// ---------------------------------------------------------------------------
// NOTIFICATIONS
// ---------------------------------------------------------------------------

export function getNotifications(userId) {
    return request(`/notifications/${userId}`);
}

export function markNotificationRead(notificationId) {
    return request(`/notifications/read/${notificationId}`, {
        method: "PUT",
    });
}

export function markAllNotificationsRead(userId) {
    return request(`/notifications/read-all/${userId}`, {
        method: "PUT",
    });
}

// ---------------------------------------------------------------------------
// CLEARANCE
// ---------------------------------------------------------------------------

export function getClearanceStatus(userId) {
    return request(`/clearance/${userId}`);
}

export function requestClearance(userId) {
    return request(`/clearance/${userId}/request`, {
        method: "POST",
    });
}

// ---------------------------------------------------------------------------
// SUGGESTIONS
// ---------------------------------------------------------------------------

export function suggestBook(userId, suggestion) {
    return request(`/suggestions`, {
        method: "POST",
        body: JSON.stringify({ userId, ...suggestion }),
    });
}

export function getSuggestions(userId) {
    return request(`/suggestions/${userId}`);
}

// ---------------------------------------------------------------------------
// ASK A LIBRARIAN
// ---------------------------------------------------------------------------

export function getMessages(userId) {
    return request(`/messages/${userId}`);
}

export function sendMessage(userId, text) {
    return request(`/messages`, {
        method: "POST",
        body: JSON.stringify({ userId, text }),
    });
}

// ---------------------------------------------------------------------------
// Recent Activities (for dashboard preview)
// ---------------------------------------------------------------------------

export function getLibraryActivities(userId) {
    return request(`/activity/${userId}`);
}


export function getBorrowById(borrowId) {
    return request(`/borrow/${borrowId}`);
}

export function clearLibraryNotifications(userId) {
    return request(`/notifications/user/${userId}/clear`, {
        method: "DELETE",
    });
}


// ---------------------------------------------------------------------------
// CDM LIBHUB — OFFICIAL INTEGRATION API
// ---------------------------------------------------------------------------

export function getLibHubBooks(params = {}) {
    const query = new URLSearchParams(params).toString();

    return request(
        `/books${query ? `?${query}` : ""}`
    );
}

export function createLibHubReservation({
    bookId,
    studentId,
    studentNumber,
    studentName,
    pickupDate,
}) {
    return request("/reservations", {
        method: "POST",
        body: JSON.stringify({
            bookId,
            studentId,
            studentNumber,
            studentName,
            pickupDate,
        }),
    });
}

export function recordLibraryAttendance({
    studentNumber,
    studentName,
    institute,
    purpose,
    timestamp,
}) {
    return request("/attendance", {
        method: "POST",
        body: JSON.stringify({
            studentNumber,
            studentName,
            institute,
            purpose,
            timestamp,
        }),
    });
}

export const getCurrentLoans = async (userId) => {
    const response = await fetch(
        `${API_URL}/api/library/borrow/current/${userId}`,
        {
            headers: getToken()
                ? { Authorization: `Bearer ${getToken()}` }
                : {},
        }
    );

    if (!response.ok) {
        throw new Error("Failed to load current borrowed books.");
    }

    return response.json();
};